import pandas as pd

data = pd.read_csv("data/^TWII.csv");
print(data.head());